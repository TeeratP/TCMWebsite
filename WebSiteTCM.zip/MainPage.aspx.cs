﻿using System;
using System.Collections.Generic;
using System.Net;
using Newtonsoft.Json.Linq;
using System.Diagnostics;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

public partial class MainPage : Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        Cal_Profit();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Cal_Profit();
    }

    protected void Cal_Profit()
    {
        var sw1 = new Stopwatch();
        var sw2 = new Stopwatch();
        var sw3 = new Stopwatch();
        var sw4 = new Stopwatch();

        sw1.Start();
        List<CurrObject> CurrencyList = Get_Curreny_list();
        sw1.Stop();

        sw2.Start();
        get_fx_polo_btrx(ref CurrencyList);
        sw2.Stop();

        sw3.Start();
        get_mining_info(ref CurrencyList);
        sw3.Stop();

        sw4.Start();
        post_result(CurrencyList);
        sw4.Stop();
    }

    //Dictionary to map Coin name with whattomine ID
    public Dictionary<string, string> WTM_ID_Dict()
    {
        return new Dictionary<string, string>
             {
                { "365", "74" },
                { "adn", "65" },
                { "adz", "157" },
                { "amber", "133" },
                { "ams", "145" },
                { "arg-scrypt", "158" },
                { "arg-sha-256", "170" },
                { "ari", "110" },
                { "aur", "40" },
                { "bcn", "103" },
                { "bela", "182" },
                { "bip", "171" },
                { "bob", "131" },
                { "bsty", "138" },
                { "bta", "144" },
                { "btc", "1" },
                { "btm", "111" },
                { "burn", "90" },
                { "cach", "97" },
                { "cap", "120" },
                { "cbx", "126" },
                { "child", "116" },
                { "ckc", "123" },
                { "cloak", "88" },
                { "crw", "165" },
                { "crypt", "86" },
                { "cto", "134" },
                { "cure", "76" },
                { "cyc", "99" },
                { "dash", "34" },
                { "dcr", "152" },
                { "dem", "180" },
                { "dgb-myriad-groestl", "112" },
                { "dgb-sha-256", "113" },
                { "dgb-skein", "114" },
                { "dgb-qubit", "115" },
                { "dgb-scrypt", "28" },
                { "dgc-sha-256", "124" },
                { "dgc-x11", "125" },
                { "dgc-scrypt", "27" },
                { "dmd", "43" },
                { "dnet", "153" },
                { "doge", "6" },
                { "dope", "61" },
                { "dp", "183" },
                { "dsh", "129" },
                { "duo-scrypt", "140" },
                { "duo-sha-256", "141" },
                { "eac", "19" },
                { "emc2", "15" },
                { "enc", "79" },
                { "epc", "136" },
                { "etc", "162" },
                { "eth", "151" },
                { "exe", "20" },
                { "exp", "154" },
                { "fcn", "102" },
                { "flt", "36" },
                { "frsh", "118" },
                { "fst", "63" },
                { "ftc", "8" },
                { "game", "147" },
                { "gb", "160" },
                { "gdn", "50" },
                { "geo", "135" },
                { "give", "51" },
                { "glc", "81" },
                { "goal", "87" },
                { "grs", "48" },
                { "hal", "122" },
                { "hiro", "33" },
                { "hush", "168" },
                { "hvc", "35" },
                { "iec", "142" },
                { "infx", "149" },
                { "jpc", "80" },
                { "karm", "38" },
                { "kmd", "174" },
                { "kr", "163" },
                { "krb", "176" },
                { "lbc", "164" },
                { "lgc", "57" },
                { "lgd", "68" },
                { "limx", "46" },
                { "ltc", "4" },
                { "ltcx", "78" },
                { "maru", "84" },
                { "max", "73" },
                { "mec", "26" },
                { "meow", "16" },
                { "meth", "75" },
                { "mil", "91" },
                { "mnd", "155" },
                { "mona", "148" },
                { "moon", "119" },
                { "mrc", "41" },
                { "mue", "143" },
                { "mun", "47" },
                { "music", "178" },
                { "myr-scrypt", "32" },
                { "myr-myriad-groestl", "49" },
                { "myr-sha-256", "56" },
                { "myr-yescrypt", "66" },
                { "myr-skein", "67" },
                { "mzc", "70" },
                { "naut", "82" },
                { "nlg", "64" },
                { "nmc", "55" },
                { "nobl", "44" },
                { "note", "146" },
                { "nvc", "30" },
                { "nyan", "17" },
                { "orb", "72" },
                { "pasc", "172" },
                { "pasl", "177" },
                { "pot", "18" },
                { "ppc", "52" },
                { "pxc", "71" },
                { "qbc", "45" },
                { "qcn", "105" },
                { "qrk", "137" },
                { "rby", "95" },
                { "rdd", "11" },
                { "ripo", "108" },
                { "rpc", "58" },
                { "rzr", "96" },
                { "sat2", "39" },
                { "sc", "161" },
                { "score", "181" },
                { "shift", "156" },
                { "sib", "169" },
                { "slg", "117" },
                { "smc", "159" },
                { "spa", "12" },
                { "spc", "77" },
                { "src", "139" },
                { "start", "132" },
                { "tac", "94" },
                { "tips", "2" },
                { "ubq", "173" },
                { "unb", "83" },
                { "uno", "54" },
                { "upm", "106" },
                { "uro", "100" },
                { "usde", "31" },
                { "utc", "3" },
                { "veil", "98" },
                { "via", "107" },
                { "vmc", "62" },
                { "vtc", "5" },
                { "wdc", "29" },
                { "xc", "69" },
                { "xcn", "184" },
                { "xdn", "104" },
                { "xhc", "109" },
                { "xlr", "179" },
                { "xmr", "101" },
                { "xpy", "121" },
                { "xvc", "130" },
                { "xvg", "150" },
                { "xzc", "175" },
                { "yac", "42" },
                { "zcl", "167" },
                { "zec", "166" },
                { "zen", "185" },
                { "zet", "53" }
            };
    }
    
    public Dictionary<string, double> get_fx_table_bx()
    {

        string[] main_currency = { "BTC", "ETH" };
        double Currency = 0;

        Dictionary<string, double> FX_Table = new Dictionary<string, double> { };

        // get BTC to THB Data
        var bx_BTC_json = new WebClient().DownloadString("https://bx.in.th/api/orderbook/?pairing=1");
        var bx_BTC_obj = JObject.Parse(bx_BTC_json);

        Currency = (double)bx_BTC_obj["bids"][0][0];
        FX_Table.Add("THB_BTC", Currency);

        // get ETH to THB Data
        var bx_ETH_json = new WebClient().DownloadString("https://bx.in.th/api/orderbook/?pairing=21");
        var bx_ETH_obj = JObject.Parse(bx_ETH_json);

        Currency = (double)bx_ETH_obj["bids"][0][0];
        FX_Table.Add("THB_ETH", Currency);

        return (FX_Table);

    }

    public List<CurrObject> Get_Curreny_list()
    {
        //Create Currency list to keep chosen currency
        List<CurrObject> CurrList = new List<CurrObject>();

        //Go through all control to check which currrency is chosen
        foreach (Control ctrl in form1.Controls)
        {
            if (ctrl.GetType() == typeof(CheckBox))
            {
                var checkBoxCtrl = (CheckBox)ctrl;
                if (checkBoxCtrl.Checked)
                {
                    // Get ID
                    string num = checkBoxCtrl.ID.Substring(3);

                    //Create new currency object
                    CurrObject Currency = new CurrObject();

                    Currency.ID = num;

                    var name = (TextBox)form1.FindControl("Cur_" + num);
                    Currency.name = name.Text;

                    var HR80 = (TextBox)form1.FindControl("HR" + num + "_80");
                    Currency.myHR_80 = Convert.ToDouble(HR80.Text);

                    var HR60 = (TextBox)form1.FindControl("HR" + num + "_60");
                    Currency.myHR_60 = Convert.ToDouble(HR60.Text);

                    var HashUnit = (DropDownList)form1.FindControl("HashUnit" + num);
                    Currency.factor = Convert.ToDouble(HashUnit.SelectedItem.Value);

                    CurrList.Add(Currency);
                }
            }
        }

        return (CurrList);
    }
    
    public void get_mining_info(ref List<CurrObject> CurrencyList)
    {
        Dictionary<string, string> WTM_Num_Table = WTM_ID_Dict();

        var WTM_json = new WebClient().DownloadString("http://whattomine.com/coins.json");
        var WTM_obj = JObject.Parse(WTM_json);

        foreach (CurrObject Currency in CurrencyList)
        {
            string Coin_name = Currency.name;
            switch (Coin_name)
            {

                case "SPR":

                    break;
                default:
                    //Get whattomine ID
                    string WTM_Num = WTM_Num_Table[Coin_name.ToLower()];

                    JToken Cur_Token = WTM_obj["coins"].SelectToken("[?(@..id == " + WTM_Num + ")]");

                    //Get Whattomine Data
                    Currency.NHR = (double)Cur_Token.First["nethash"];
                    Currency.BlockTime = (double)Cur_Token.First["block_time"];
                    Currency.BlockReward = (double)Cur_Token.First["block_reward"];
                    break;
            }
            Currency.get_return();
        }
    }

    public void get_fx_polo_btrx(ref List<CurrObject> CurrencyList)
    {

        string[] main_currency = { "BTC" };

        var polo_json = new WebClient().DownloadString("https://poloniex.com/public?command=returnOrderBook&currencyPair=all&depth=1");
        var btrx_json = new WebClient().DownloadString("https://bittrex.com/api/v1.1/public/getmarketsummaries");

        var polo_obj = JObject.Parse(polo_json);
        var btrx_obj = JObject.Parse(btrx_json);

        foreach (CurrObject Currency in CurrencyList)
        {
            string Coin_name = Currency.name;

            foreach (string out_coin in main_currency)
            {

                string Name_polo = out_coin + "_" + Coin_name;
                string Name_btrx = out_coin + "-" + Coin_name;

                try
                {
                    Currency.FX = (double)polo_obj[Name_polo]["bids"][0][0];
                }
                catch
                {
                    try
                    {
                        JToken Cur_Token = btrx_obj.SelectToken("$.result[?(@.MarketName == '" + Name_btrx + "')]");

                        Currency.FX = (double)Cur_Token["Bid"];
                    }
                    catch
                    {
                        Currency.FX = 0;
                    }
                }

            }
        }
    }

    public void post_result(List<CurrObject> CurrencyList)
    {
        DataTable dt = new DataTable();
        dt.Columns.Add("Currency", typeof(string));
        dt.Columns.Add("1080Ti", typeof(string));
        dt.Columns.Add("1060", typeof(string));

        foreach(CurrObject Currency in CurrencyList)
        {
            dt.Rows.Add(Currency.name, 
                String.Format("{0,12:#0.000}", Currency.btc_rev_80 * 1000), 
                String.Format("{0,12:#0.000}", Currency.btc_rev_60 * 1000));
        }
        GridView1.DataSource = dt;
        GridView1.DataBind();


    }

    public class CurrObject
    {
        public string ID { get; set; }
        public string name { get; set; }

        //From poloniex or bittrex
        public double FX { get; set; }

        // From WTM or their website
        public double NHR { get; set; }
        public double BlockTime { get; set; }
        public double BlockReward { get; set; }

        // From website
        public double myHR_80 { get; set; }
        public double myHR_60 { get; set; }
        public double factor { get; set; }

        public double btc_rev_80;
        public double btc_rev_60;

        public void get_return()
        {
            btc_rev_80 = myHR_80 / NHR * (86400 / BlockTime) * BlockReward * FX * factor;
            btc_rev_60 = myHR_60 / NHR * (86400 / BlockTime) * BlockReward * FX * factor;
        }

    }
    
}